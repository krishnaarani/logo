export const accordion: string;
export const accordionButton: string;
export const accordionContent: string;
export const accordionContentactive: string;
export const accordionHidden: string;
