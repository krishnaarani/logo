import React, { useState } from 'react'
import AccTitleProps from './AccTitleProps';
import AccTitleState from './AccTitleState';
import * as styles from './AccTitle.scss';



export default class AccTitle extends
    React.PureComponent<AccTitleProps, AccTitleState> {
    state: AccTitleState;

    constructor(props) {
        super(props);
        this.handleToggleVisibility = this.handleToggleVisibility.bind(this);
        this.state = {
            visibility: false
        }
    }

    handleToggleVisibility() {
        this.setState((prevState) => ({

                visibility: !prevState.visibility,
            }
        ));
    }
    render() {
      console.log("visibility",this.state.visibility)
      console.log("this.props.hiddenTexts.value", this.props.hiddenTexts.value)
        return (
            <div>
                <button className={styles.accordionButton} onClick={() => this.handleToggleVisibility()}>{this.props.hiddenTexts.label}<span className={this.state.visibility? 'fas fa-minus': 'fas fa-plus'}></span></button>
                <p className={this.state.visibility ? styles.accordionContentactive : styles.accordionHidden }>
                {
                    this.props.hiddenTexts.value
                }
                </p>

            </div>
        );
    }

}
