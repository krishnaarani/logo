export default interface ReactAccordionProps {
    hiddenTexts? : any

}