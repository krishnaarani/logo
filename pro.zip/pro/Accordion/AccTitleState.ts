
export default class ReactAccordionState {
    visibility: boolean
}
