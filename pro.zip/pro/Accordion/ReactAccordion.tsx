
import ReactAccordionProps from './ReactAccordionProps';
import ReactAccordionState from './ReactAccordionState';
import * as styles from './ReactAccordion.scss';
import AccTitle from './AccTitle';
import React from 'react'



export default class ReactAccordion extends
    React.PureComponent<ReactAccordionProps, ReactAccordionState> {
    state: ReactAccordionState;



    constructor(props: ReactAccordionProps) {
        super(props);

    }


    render() {
      return (
          <div className={styles.accordion}>
              {this.props.hiddenTexts.map((hiddenText) => <AccTitle key={hiddenText.label} hiddenTexts={hiddenText} />)}
          </div>
      );
  }

}
