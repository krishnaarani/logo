export default interface ReactAccordionProps {
    hiddenTexts? : any,
    hiddenText?: any

}