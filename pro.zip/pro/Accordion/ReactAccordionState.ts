
export default class ReactAccordionState {

}
