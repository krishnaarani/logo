import ReactAccordion from './ReactAccordion';
export default ReactAccordion;
