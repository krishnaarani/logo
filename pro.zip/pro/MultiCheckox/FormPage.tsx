//import 'core-js/stable';
import * as React from 'react';

export default class FormPage extends React.PureComponent {
    render() {
        console.log(this.props.checked)


      return (
        <>

          <div>
              form
          </div>
          </>
      );
  }

}
