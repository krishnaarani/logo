export const container: string;
export const checkmark: string;
export const submit: string;
export const container1: string;
export const centered: string;
export const banner: string;
