
import React from 'react';
import * as styles from '../MultiCheckox/MultiCheck.scss';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import FormPage from './FormPage';

interface MultiCheckProps {
    router?: any;
  }

export default class MultiCheck extends React.PureComponent<MultiCheckProps> {
    constructor() {
        super();
        this.state = {
        checked : '' };
        this.handleChange = this.handleChange.bind(this);
        this.handleData = this.handleData.bind(this);
    }

    handleChange(e) {
        var abc = e.target.value;
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');
        // this.setState({ checkedVal: checkboxes });
        var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
         this.setState({ checked: checkedOne });
        (document.querySelectorAll('input[type="submit"]')[0] as HTMLInputElement).disabled = true;
        if (checkedOne) {
            (document.querySelectorAll('input[type="submit"]')[0] as HTMLInputElement).disabled = false;
        }
    }

    getData() {
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');
        return checkboxes;
    }

    handleData(event) {


        return (
            <Router>
                <Switch>
                    <Route path="/reactform"
                           render={() =>
                               <FormPage checked={this.state.checked}
                                    // age={this.state.age}
                                    />
                           } />
                    {/* <Route path="/home"
                           render={() =>
                               <Home name={this.state.name} />
                           } /> */}
                </Switch>
            </Router>
        )
        // var checkboxes = document.querySelectorAll('input[type="checkbox"]');

        // var bucket = (document.getElementById('bucket')as HTMLInputElement).value
        // var newProject  = (document.getElementById('newProject')as HTMLInputElement).value
        // var cloudSql  = (document.getElementById('cloudSql')as HTMLInputElement).value
        // var gkeCluster  = (document.getElementById('gkeCluster')as HTMLInputElement).value
        // var virtualMachine  = (document.getElementById('virtualMachine')as HTMLInputElement).value
        // //  console.log(bucket, newProject, cloudSql, gkeCluster, virtualMachine)
        //  if(this.state.checked) {
            // this.props.router.push({
            //     pathname: '/reactform',
            //     // state: {
            //     // //   checked: this.state.checked,
            //     //   checkVal: this.getData()
            //  //   }
            //   })
        //  }
        // // var form_data = new FormData(document.querySelector("form"));
        // // if()
        // window.location.href = '/reactform'
        // event.preventDefault();
        // console.log("form data: ");
        //   for(var pair of form_data.entries())
        //   {
        //       console.log(pair[0]+ ' : '+ pair[1]);
        //   }
        return true;
    }

    render() {

        return (
            <div>
                <div>
                    <form onSubmit={this.handleData}>
                        <div>

                            <label className={styles.container} for="bucket">
                                <input type="checkbox"  onChange={this.handleChange} name="bucket" id="bucket" />
                                <span className={styles.checkmark}></span>
  Bucket</label>
                        </div>
                        <div>

                            <label className={styles.container} for="newProject">
                                <input type="checkbox"  onChange={this.handleChange} name="newProject" id="newProject" />
                                <span className={styles.checkmark}></span>
New Project</label>
                        </div>
                        <div>

                            <label className={styles.container} for="cloudSql">
                                <input type="checkbox"   onChange={this.handleChange} name="cloudSql" id="cloudSql" />
                                <span className={styles.checkmark}></span>
Cloudsql Instance</label>
                        </div>
                        <div>

                            <label className={styles.container} for="gkeCluster">
                                <input type="checkbox" onChange={this.handleChange} name="gkeCluster" id="gkeCluster" />
                                <span className={styles.checkmark}></span>
GKE cluster</label>
                        </div>
                        <div>

                            <label className={styles.container} for="virtualMachine">
                                <input type="checkbox" name="virtualMachine" onChange={this.handleChange} id="virtualMachine" />
                                <span className={styles.checkmark}></span>
  Virtual Machine</label>
                        </div>
                        <div>
                            <input type="submit" id='submit' className={styles.submit} name="submit" value="Submit" disabled />
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}