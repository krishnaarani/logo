//import 'core-js/stable';
import * as React from 'react';
import MultiCheck from '../src/components/MultiCheckox/MultiCheck';
import ReactAccordion from '../src/components/Accordion/ReactAccordion';
import autoban from '../src/images/tray.png';
import * as styles from '../src/components/MultiCheckox/MultiCheck.scss';

export default class Accordion extends React.PureComponent {
    render() {
      // const title = 'Accordion App';
      const hiddenTexts = [{
          label: 'GCP',
          value: this.abcd(),
      },
      {
          label: 'On Prem',
          value: 'Text of Accordion 2'
      },
      {
          label: 'Azure',
          value: 'Text of Accordion 3'
      }];


      return (
        <>
        <head>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css"></link>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/lato-font/3.0.0/css/lato-font.min.css"></link>
        </head>
          <div style={{paddingTop: '20px'}}>
              <div className={styles.container1}>
                  <img src={autoban} className={styles.banner}/>
                  <div className={styles.centered}>Infrastructure Pipeline</div>
              </div>
              <ReactAccordion hiddenTexts={hiddenTexts} />
          </div>
          </>
      );
  }
    abcd() {
        return (
            <MultiCheck/>
        )
    }
}
