//import 'core-js/stable';
import * as React from 'react';
import FormPage from '../src/components/MultiCheckox/FormPage';

export default class ReactForm extends React.PureComponent {
    render() {
    //  console.log(this.state.checked)
    //  console.log(this.state.checkVal)


      return (
        <>

          <div>
              Hello
            {/* <FormPage></FormPage> */}
          </div>
          </>
      );
  }

}
